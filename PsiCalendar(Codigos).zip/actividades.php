<?php
/*Obtener informacion para prevenir cruce de datos */
require_once "config.php";
require_once "functions.php";


check_login();

/* Lista generada de actividaes a escojer */
$actividades = [
    "Medita con un video de youtube por 10 minutos",
    "Da un paseo de 15 minutos",
    "Escribir 10 cosas por las que estás agradecido",
    "Llamar a tu mejor amigo y dile lo mucho que lo aprecias",
    "Leer un capítulo del titulo (Cumbres Borracosas) de Emily Bronte",
    "Haz un origami de perrito!",
    "Sal a ver el panorama de tu casa por 10 mins y respira",
    "Busca en Spotify (El miedo al cambio) de Farid Dieck - 17 mins",
    "Dibuja un paisaje de algun lugar que hayas visitado",
    "Prueba a escuchar One More Time - de Daft Punk",
    "Escribe que es lo que sientes al escuchar el Himno a la Alegria de Beethoven",
    "Has escuchado Highway to Hell - de AC/DC , es interesante buscalo",
    "Sabias de las curiosidades de la cancion Another Brick in the Wall Pt2? , te deja mucho en que pensar",
    "Si tienes un incienso a dispoción prendelo y pon musica china",
    "Haz una lista de gratitud a las personas que mas aprecias",
    "Preparate un jugo de limon e invita a tus amigos a tomar de el",
    "Busca en Youtube Luisito Comunica - Ecuador , puedes aprender algo que no sabias",
    "Sabes de donde proviene la palabra (Ñaño)? te apuesto a que no , hora de la busqueda",
    "Quieres conocer musica folkclorica alegre? Busca Los Herederos de Tabacundo en Youtube",
    "Revive los 90s Busca Tren al Sur - Los Prisioneros",
    "Prueba a buscar Big in Japan - Alphaville , es antiguo pero bueno",
    "Echate una salsa mi rey/reina vamoooo",
    "Busca (Darle valor a las pequeñas metas) - Entiende Tu Mente en Spotify",
    "Escucha Pobre Secretaria - Daniela Romo , pa que te rias y bailes ",
    "Busca - De Musica Ligera - Soda Stereo , un clasicazo",
    "Busca Every Breath You Take - The Police , subtitulado en español en Youtube",
    "Escribe sobre las cosas que te gustan hacer",
    "A Bailar , busca Chantaje - Just Dance en Youtube y sigue los pasos!",
    "Otro Clasico , busca Torero de Chayanne y a bailar!!",
    "Busca Respiracion Guiada en Youtube y aplica lo que aprendiste",
    "Haz un origami de un sapito que salte!",
    "Busca Im Still Standing - Elton Jhon en español y fijate en su letra",
    "Toma un baño caliente",
    "Busca alguna receta sencilla para hacer en tu cocina",
    "Tienes plantas? Hora de apreciarla , dales agua y mueve su tierra",
    "Toma una taza de cafe",
    "Hazte un masaje en los pies!",
    "Busca el articulo del dia en WikiPedia",
    "Busca Isla del Tesoro - Robert Louis Stevenson y lee el primer capitulo",
    "Hora de ver tus fotos y recordar viejos tiempos!",
    "Hora del te!, preparate una aguita aromatica",
    "Busca Ejercicios de Yoga para principiantes",
    "Sal a la terraza o fuera de casa y estirate",
    "Lee sobre las poesias de Paulo Coelho",
    "Practica tu escritura por 10 mins",
    "Tu cuarto esta limpio? , vamos a reacomodar!!",
    "Abre tu telefono y toma fotos de tu entorno , como un profesional",
    "Revive el 2010 Busca Carito - Carlos Vives",
    "A bailar Busca Calypso - Luis Fonsi Just Dance y a mover el bote!!",
    "De donde salio de los ecuatorianos decir (Seco de Pollo)? vamos a buscar!"

];

/*Lista de frases a escojer*/
$frases = [
    "La vida es lo que hacemos de ella. Los viajes son los viajeros. Lo que vemos no es lo que vemos, sino lo que somos. - Fernando Pessoa",
    "La felicidad no es algo que pospones para el futuro; es algo que diseñas para el presente. - Jim Rohn",
    "La única manera de hacer un gran trabajo es amar lo que haces. - Steve Jobs",
    "No te preocupes por los fracasos, preocúpate por las oportunidades que pierdes cuando ni siquiera lo intentas. - Jack Canfield",
    "La vida es un regalo, y quiero aprovecharlo al máximo. - Kate Winslet",
    "No cuentes los días, haz que los días cuenten. - Muhammad Ali",
    "La vida es corta, y es hasta cierto punto un desperdicio de tiempo ocuparse de asuntos serios. - Oscar Wilde",
    "No hay manera de ser una persona perfecta, pero hay un millón de maneras de ser una persona increíble. - Anonimo",
    "La verdadera felicidad consiste en hacer el bien. - Aristóteles",
    "El éxito no es la clave de la felicidad. La felicidad es la clave del éxito. Si amas lo que haces, tendrás éxito. - Albert Schweitzer",
    "Cree en ti mismo y todo será posible. - Friedrich Nietzsche",
    "La vida no se trata de esperar a que pase la tormenta, se trata de aprender a bailar bajo la lluvia. - Vivian Greene",
    "Nunca pierdas la esperanza, los milagros ocurren todos los días. - H. Jackson Brown Jr.",
    "La mayor gloria en la vida no es nunca caer, sino levantarse cada vez que caemos. - Nelson Mandela",
    "No importa lo lento que vayas siempre y cuando no te detengas. - Confucio",
    "La vida es un viaje que debe ser viajado, sin importar lo malas que sean las carreteras y lo cansado que uno se sienta. - Oliver Goldsmith",
    "La vida es realmente simple, pero insistimos en hacerlo complicado. - Confucio",
    "El éxito es la suma de pequeños esfuerzos repetidos día tras día. - Robert Collier",
    "La felicidad no es algo que pospones para el futuro; es algo que diseñas para el presente. - Jim Rohn",
    "Nada puede resistir al trabajo perseverante. - Alejandro Magno"
];

/*Funcion para seleccionar aleatoriamente 3 actividades y 1 frase */
$actividades_seleccionadas = array_rand($actividades, 3);
$frase_del_dia = $frases[array_rand($frases)];

/*Llamada al titulo de la pagina*/
$titulo_pagina = "Actividades Sugeridas - PsiCalendar";
include "templates/header.php";
?>
<!-- Video del Fondo de esta pagina -->
<div class="video-container4">
    <video autoplay muted loop id="video-background4">
        <source src="vids/videofondoactividades.mp4" type="video/mp4">
        Tu navegador no soporta videos HTML5.
    </video>
</div>

<!-- Titulo Grande -->
<h2>Actividades Sugeridas para Hoy</h2>
<br><br>
<ul>
    <!-- Impresion de las actividades -->
    <?php foreach ($actividades_seleccionadas as $index): ?>
        <li><?php echo $actividades[$index]; ?></li>
    <?php endforeach; ?>
</ul>
<br><br>
<h3>Frase del Día</h3>
<br>
<!-- Impresion de la frase del dia -->
<p><?php echo $frase_del_dia; ?></p>

<?php
if (isset($_SESSION['mensaje'])) {
    echo "<div class='alert alert-success'>" . $_SESSION['mensaje'] . "</div>";
    unset($_SESSION['mensaje']);
}
?>
<!-- Creacion de los botones , con  redireccionamiento al click -->
<div class="mt-4">
    <a href="calendario.php" class="btn btn-primary">Volver al Calendario</a>
    <br><br>
    <a href="logout.php" class="btn btn-danger">Cerrar Sesión</a>
</div>

<?php include "templates/footer.php"; ?>