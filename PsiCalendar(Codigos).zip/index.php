<!-- Inicio del Codigo en HTML -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PsiCalendar - Home</title>
</head>
<body>
    <div class="video-container">
        <video autoplay muted loop id="video-background">
            <source src="vids/fondoindex.mp4" type="video/mp4">
            Tu navegador no soporta videos HTML5.
        </video>
    </div>
    <?php
    /* Tomar Header de la carpeta templates */
    $titulo_pagina = "Inicio - PsiCalendar";
    include "templates/header.php";
    ?>
<!-- Pagina Index  -->
    <br><br>
    <h1>Bienvenido a PsiCalendar</h1>
    <img id="logo" src=img/PsiCalendar.png width="900" height="145">
    <br>
    <p>Aquí puedes llevar un registro de tus emociones 
    <p>y recibir sugerencias de actividades para mejorar tu bienestar.</p>
    <br><br>
    <?php if (!isset($_SESSION['usuario_id'])): ?>
        <!-- Entrar al Login -->
        <a href="login.php" class="btn btn-primary">Iniciar Sesión</a>
        <!-- Entrar al Registro -->
        <a href="registro.php" class="btn btn-secondary">Registrarse</a>
    <?php endif; ?>
    <!-- Tomar Footer de la carpeta templates -->
    <br><br>
    <?php include "templates/footer.php"; ?>
</body>
</html>