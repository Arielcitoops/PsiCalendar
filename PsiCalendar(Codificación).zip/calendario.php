<?php
require_once "config.php";
require_once "functions.php";

/*Revision del login correcto*/
check_login();

/*Obtener id*/
$user_id = get_user_id();

/*Obtencion de de datos de la base SQL - Sentencia primaria*/
$sql = "SELECT * FROM registros_diarios WHERE usuario_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

/*Agarrar resultados para postproceso del dato*/
$eventos = array();
while ($row = mysqli_fetch_assoc($result)) {
    $color = array(
        'alegre' => '#FFFF00',
        'triste' => '#0000FF',
        'cansado' => '#00FF00',
        'enojado' => '#FF0000'
    )[$row['emocion']] ?? '#FFFFFF';

    $eventos[] = array(
        'title' => ucfirst($row['emocion']),
        'start' => $row['fecha'],
        'color' => $color,
        'extendedProps' => array(
            'emocion' => $row['emocion'],
            'intensidad' => $row['intensidad'],
            'anecdota' => $row['anecdota']
        )
    );
}

/*Llamada al titulo de la pagina*/
$titulo_pagina = "Calendario - PsiCalendar";
include "templates/header.php";
?>
<!-- Video del Fondo de esta pagina -->
<div class="video-container2">
    <video autoplay muted loop id="video-background2">
        <source src="vids/videofondocalendario.mp4" type="video/mp4">
        Tu navegador no soporta videos HTML5.
    </video>
</div>
<div id="calendar"></div>

<!-- Llamada a la libreira FullCalendar CSS -->
<link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.10.2/main.min.css' rel='stylesheet' />

<!--Llamada a la libreria FullCalendar JS -->
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.10.2/main.min.js'></script>

<!-- Script JS para renderizacion/funcionamiento del calendario-->
<script>
document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');
    /*Creacion del Calendario*/
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        events: <?php echo json_encode($eventos); ?>,
        /*Obtencion del dia*/
        eventClick: function(info) {
            var clickedDate = info.event.start;
            var currentDate = new Date();
            currentDate.setHours(0, 0, 0, 0);
            /*Funcion onclick del dia del calendario*/
            if (clickedDate <= currentDate) {
                var fecha = info.event.startStr;
                /*Imprimir la fecha innerHTML*/
                window.location.href = '/PsiCalendarvPHP/registro_diario.php?fecha=' + fecha;
            } else {
                /*Validacion no ingresar a fechas futuras*/
                alert('No puedes registrar emociones para fechas futuras.');
            }
        },
        /*Funcion Onclick*/
        dateClick: function(info) {
            var clickedDate = new Date(info.dateStr);
            var currentDate = new Date();
            currentDate.setHours(0, 0, 0, 0);

            if (clickedDate <= currentDate) {
                window.location.href = '/PsiCalendarvPHP/registro_diario.php?fecha=' + info.dateStr;
            } else {
                alert('No puedes registrar emociones para fechas futuras.');
            }
        }
    });
    /*Llamada a la funcion render para mostrar el calendario*/
    calendar.render();
});
</script>

<?php include "templates/footer.php"; ?>