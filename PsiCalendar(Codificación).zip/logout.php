<!-- Inicio del Codigo en HTML -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PsiCalendar - Logout</title>
</head>
<body>
   
    <?php
    /* Tomar Header de la carpeta templates */
    $titulo_pagina = "Inicio - PsiCalendar";
    include "templates/header.php";
    ?>
<!-- Pagina Index  -->
    <h1>Gracias por usarnos</h1>
    <br>
    <p>Recuerda que puedes enviarnos tus sugerencias a este correo:</p>
    <br>
    <p>arielare2004@gmail.com</p>
    <a href="index.php" class="btn btn-secondary">Volver al Inicio</a>
    <br><br><br><br><br><br><br><br><br><br>
    <!-- Tomar Footer de la carpeta templates -->
    <?php include "templates/footer.php"; ?>
</body>
</html>