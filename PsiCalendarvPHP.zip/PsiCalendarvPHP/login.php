<?php
require_once "config.php";
require_once "functions.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = trim($_POST["usuario"]);
    $password = trim($_POST["password"]);
    
    $sql = "SELECT id, usuario, password FROM usuarios WHERE usuario = ?";
    
    if($stmt = mysqli_prepare($conn, $sql)){
        mysqli_stmt_bind_param($stmt, "s", $param_username);
        $param_username = $username;
        
        if(mysqli_stmt_execute($stmt)){
            mysqli_stmt_store_result($stmt);
            
            if(mysqli_stmt_num_rows($stmt) == 1){
                mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                if(mysqli_stmt_fetch($stmt)){
                    if(password_verify($password, $hashed_password)){
                        // Contraseña correcta, iniciar sesión
                        $_SESSION["loggedin"] = true;
                        $_SESSION["id"] = $id;
                        $_SESSION["username"] = $username;                            
                        
                        header("location: calendario.php");
                        exit;
                    } else{
                        $login_err = "Usuario o contraseña incorrectos.";
                    }
                }
            } else{
                $login_err = "Usuario o contraseña incorrectos.";
            }
        } else{
            echo "Oops! Algo salió mal. Por favor, inténtalo de nuevo más tarde.";
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "No se pudo preparar la consulta SQL.";
    }
}

include "templates/header.php";
?>

<h2>Iniciar Sesión</h2>
<?php 
if(!empty($login_err)){
    echo '<div class="alert alert-danger">' . $login_err . '</div>';
}
?>
<form method="post" action="">
    <div class="form-group">
        <label for="usuario">Usuario:</label>
        <input type="text" class="form-control" id="usuario" name="usuario" required>
    </div>
    <div class="form-group">
        <label for="password">Contraseña:</label>
        <input type="password" class="form-control" id="password" name="password" required>
    </div>
    <button type="submit" class="btn btn-primary">Iniciar Sesión</button>
</form>

<?php include "templates/footer.php"; ?>
