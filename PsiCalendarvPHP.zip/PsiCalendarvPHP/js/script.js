document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');
    
    // Verifica que el elemento del calendario existe
    if (!calendarEl) {
        console.error("El elemento con ID 'calendar' no se encontró en el DOM.");
        return;
    }

    var eventos = JSON.parse(calendarEl.getAttribute('data-eventos'));
    
    console.log("Eventos:", eventos); // Depuración

    if (!eventos || eventos.length === 0) {
        console.log("No hay eventos para mostrar.");
        calendarEl.innerHTML = "No hay eventos para mostrar.";
        return;
    }

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        events: eventos,
        eventClick: function(info) {
            var evento = info.event.extendedProps;
            alert('Emoción: ' + evento.emocion + '\nIntensidad: ' + evento.intensidad + '\nAnecdota: ' + evento.anecdota);
        }
    });
    calendar.render();
});
