<?php
session_start();

function check_login() {
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: login.php");
        exit;
    }
}

function get_user_id() {
    return isset($_SESSION["id"]) ? $_SESSION["id"] : null;
}

// Otras funciones útiles aquí...
?>