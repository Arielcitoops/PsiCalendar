<?php
require_once "config.php";
require_once "funciones.php";

redirigirSiNoLogueado();

$actividades = [
    "Meditar por 10 minutos",
    "Dar un paseo de 15 minutos",
    "Escribir 3 cosas por las que estás agradecido",
    "Llamar a un amigo o familiar",
    "Leer un capítulo de un libro"
];

$frases = [
    "La felicidad es un viaje, no un destino",
    "El éxito es la suma de pequeños esfuerzos repetidos día tras día",
    "La vida es 10% lo que te sucede y 90% cómo reaccionas a ello"
];

$actividades_seleccionadas = array_rand($actividades, 3);
$frase_del_dia = $frases[array_rand($frases)];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Actividades Sugeridas - PsiCalendar</title>
</head>
<body>
    <h2>Actividades Sugeridas para Hoy</h2>
    <ul>
        <?php foreach ($actividades_seleccionadas as $index): ?>
            <li><?php echo $actividades[$index]; ?></li>
        <?php endforeach; ?>
    </ul>

    <h3>Frase del Día</h3>
    <p><?php echo $frase_del_dia; ?></p>
</body>
</html>