<?php
require_once "config.php";
require_once "funciones.php";

redirigirSiNoLogueado();

$usuario_id = $_SESSION['usuario_id'];

$sql = "SELECT nombre, correo, usuario FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$resultado = $stmt->get_result();
$usuario = $resultado->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];

    $sql = "UPDATE usuarios SET nombre = ?, correo = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $nombre, $correo, $usuario_id);

    if ($stmt->execute()) {
        $mensaje = "Perfil actualizado con éxito.";
    } else {
        $error = "Error al actualizar el perfil.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Perfil - PsiCalendar</title>
</head>
<body>
    <h2>Perfil de Usuario</h2>
    <form method="post" action="">
        <input type="text" name="nombre" value="<?php echo $usuario['nombre']; ?>" required><br>
        <input type="email" name="correo" value="<?php echo $usuario['correo']; ?>" required><br>
        <p>Usuario: <?php echo $usuario['usuario']; ?></p>
        <input type="submit" value="Actualizar Perfil">
    </form>
</body>
</html>