<?php
require_once "config.php";
require_once "funciones.php";

redirigirSiNoLogueado();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario_id = $_SESSION['usuario_id'];
    $fecha = $_POST['fecha'];
    $emocion = $_POST['emocion'];
    $intensidad = $_POST['intensidad'];
    $anecdota = $_POST['anecdota'];

    $sql = "INSERT INTO registros_diarios (usuario_id, fecha, emocion, intensidad, anecdota) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issss", $usuario_id, $fecha, $emocion, $intensidad, $anecdota);

    if ($stmt->execute()) {
        header("Location: calendario.php");
        exit();
    } else {
        $error = "Error al guardar el registro.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registro Diario - PsiCalendar</title>
</head>
<body>
    <h2>Registro Diario</h2>
    <form method="post" action="">
        <input type="date" name="fecha" required><br>
        <select name="emocion" required>
            <option value="alegre">Alegre</option>
            <option value="triste">Triste</option>
            <option value="enojado">Enojado</option>
            <option value="cansado">Cansado</option>
        </select><br>
        <input type="number" name="intensidad" min="1" max="10" required><br>
        <textarea name="anecdota" placeholder="¿Qué pasó hoy?" required></textarea><br>
        <input type="submit" value="Guardar Registro">
    </form>
</body>
</html>