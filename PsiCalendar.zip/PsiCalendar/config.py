import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'tu_clave_secreta'
    SQLALCHEMY_DATABASE_URI = (
        f"mysql+mysqlconnector://{os.environ.get('root')}:"
        f"{os.environ.get('rootroot')}@/"
        f"{os.environ.get('bdd_psicalendar')}?"
        f"unix_socket=/cloudsql/{os.environ.get('psicalendar:us-central1:bdd-1psicalendar')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False