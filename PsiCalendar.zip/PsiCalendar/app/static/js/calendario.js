document.addEventListener('DOMContentLoaded', function() {
    const calendarEl = document.getElementById('calendario');
    const registroDiario = document.getElementById('registro-diario');
    const fechaSeleccionada = document.getElementById('fecha-seleccionada');

    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        selectable: true,
        select: function(info) {
            const hoy = new Date();
            const fechaSeleccion = info.start;

            if (fechaSeleccion <= hoy) {
                mostrarRegistroDiario(fechaSeleccion);
            } else {
                alert('No puedes seleccionar fechas futuras.');
            }
        },
        events: eventos,
        eventClick: function(info) {
            mostrarDetallesRegistro(info.event);
        }
    });

    calendar.render();

    function mostrarRegistroDiario(fecha) {
        fechaSeleccionada.value = fecha.toISOString().split('T')[0];
        registroDiario.style.display = 'block';
    }

    function mostrarDetallesRegistro(evento) {
        alert(`
            Fecha: ${evento.start.toLocaleDateString()}
            Emoción: ${evento.extendedProps.emocion}
            Intensidad: ${evento.extendedProps.intensidad}
            Anécdota: ${evento.extendedProps.anecdota}
        `);
    }
});