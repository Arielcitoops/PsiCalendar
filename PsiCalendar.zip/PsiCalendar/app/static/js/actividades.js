document.addEventListener('DOMContentLoaded', function() {
    const actividades = document.querySelectorAll('.actividades-container li');
    actividades.forEach(actividad => {
        actividad.addEventListener('click', function() {
            this.classList.toggle('completada');
        });
    });

    const galletas = document.querySelectorAll('.galleta-fortuna');
    galletas.forEach(galleta => {
        galleta.addEventListener('click', function() {
            this.classList.add('abierta');
        });
    });
});