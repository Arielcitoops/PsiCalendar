document.addEventListener('DOMContentLoaded', function() {
    const registroForm = document.querySelector('form');
    registroForm.addEventListener('submit', function(e) {
        const nombre = document.querySelector('input[name="nombre"]').value;
        const correo = document.querySelector('input[name="correo"]').value;
        const edad = document.querySelector('input[name="edad"]').value;
        const genero = document.querySelector('select[name="genero"]').value;
        const usuario = document.querySelector('input[name="usuario"]').value;
        const password = document.querySelector('input[name="password"]').value;
        
        if (!nombre || !correo || !edad || !genero || !usuario || !password) {
            e.preventDefault();
            alert('Por favor, completa todos los campos.');
        }
        
        if (password.length < 8) {
            e.preventDefault();
            alert('La contraseña debe tener al menos 8 caracteres.');
        }
    });
});