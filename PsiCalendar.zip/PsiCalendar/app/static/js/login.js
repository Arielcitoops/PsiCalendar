document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.querySelector('form');
    loginForm.addEventListener('submit', function(e) {
        const usuario = document.querySelector('input[name="usuario"]').value;
        const password = document.querySelector('input[name="password"]').value;
        
        if (!usuario || !password) {
            e.preventDefault();
            alert('Por favor, completa todos los campos.');
        }
    });
});