document.addEventListener('DOMContentLoaded', function() {
    const loginContainer = document.querySelector('.login-container');
    
    // Adding fade-in animation to the login container
    loginContainer.classList.add('fade-in');
});