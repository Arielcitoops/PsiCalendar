from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, Usuario, RegistroDiario
from config import Config
import random
from datetime import datetime
import json

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return Usuario.query.get(int(user_id))

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        usuario = request.form['usuario']
        password = request.form['password']
        user = Usuario.query.filter_by(usuario=usuario).first()
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('calendario'))
        else:
            flash('Usuario o contraseña incorrectos')
    return render_template('login.html')

@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        nombre = request.form['nombre']
        correo = request.form['correo']
        edad = request.form['edad']
        genero = request.form['genero']
        usuario = request.form['usuario']
        password = request.form['password']
        
        user = Usuario(nombre=nombre, correo=correo, edad=edad, genero=genero, usuario=usuario)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        flash('Registro exitoso. Por favor, inicie sesión.')
        return redirect(url_for('login'))
    return render_template('registro.html')

@app.route('/calendario')
@login_required
def calendario():
    registros = RegistroDiario.query.filter_by(usuario_id=current_user.id).all()
    eventos = []
    for registro in registros:
        color = {
            'alegre': '#FFFF00',
            'triste': '#0000FF',
            'cansado': '#00FF00',
            'enojado': '#FF0000'
        }.get(registro.emocion, '#FFFFFF')
        
        eventos.append({
            'title': registro.emocion.capitalize(),
            'start': registro.fecha.isoformat(),
            'color': color,
            'extendedProps': {
                'emocion': registro.emocion,
                'intensidad': registro.intensidad,
                'anecdota': registro.anecdota
            }
        })
    
    return render_template('calendario.html', eventos=json.dumps(eventos))

@app.route('/registro_diario', methods=['POST'])
@login_required
def registro_diario():
    fecha = datetime.strptime(request.form['fecha'], '%Y-%m-%d').date()
    emocion = request.form['emocion']
    intensidad = request.form['intensidad']
    anecdota = request.form['anecdota']
    
    registro = RegistroDiario(usuario_id=current_user.id, fecha=fecha, emocion=emocion, 
                              intensidad=intensidad, anecdota=anecdota)
    db.session.add(registro)
    db.session.commit()
    return redirect(url_for('calendario'))

@app.route('/actividades')
@login_required
def actividades():
    actividades = [
        "Meditar por 10 minutos",
        "Dar un paseo de 15 minutos",
        "Escribir 3 cosas por las que estás agradecido",
        "Llamar a un amigo o familiar",
        "Leer un capítulo de un libro"
    ]
    frases = [
        "La felicidad es un viaje, no un destino",
        "El éxito es la suma de pequeños esfuerzos repetidos día tras día",
        "La vida es 10% lo que te sucede y 90% cómo reaccionas a ello"
    ]
    actividades_seleccionadas = random.sample(actividades, 4)
    frase_del_dia = random.choice(frases)
    return render_template('actividades.html', actividades=actividades_seleccionadas, frase=frase_del_dia)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)